# Week 23: Dictionaries & Functions - Core Game Mechanics

Welcome to Week 23! This week you'll build the foundation of the Pokemon Battle Game using dictionaries and functions - a powerful functional programming approach.

## Overview

You'll implement:
- **Pokemon State Management**: HP tracking, fainting, and stats
- **Team Management**: Creating teams, adding Pokemon, and switching
- **Team State Checks**: Checking team status and properties
- **Basic Move Mechanics**: Hit/miss calculation based on accuracy

## Project Structure

Working files:
- `pokemon.py` - Pokemon state functions (TODO 1, TODO 3.3)
- `team.py` - Team management functions (TODO 2, TODO 3.1-3.2)
- `move.py` - Move mechanics (TODO 4)

---

## Understanding the Data Structures

### Pokemon Dictionary
```python
{
    "name": "Pikachu",
    "types": ["electric"],
    "stats": {"hp": 110, "attack": 80, "defense": 70, "speed": 120},
    "max_hp": 110,
    "current_hp": 110,
    "level": 50,
    "move": {...}
}
```

### Team Dictionary
```python
{
    "pokemon_list": [pokemon1, pokemon2, ...],  # Max 6
    "current_pokemon_index": 0
}
```

**Key Concept**: Dictionaries are mutable. Modifying a Pokemon's HP in a function changes the actual dictionary.

---

## TODO 1: Pokemon State Management

**File**: `pokemon.py`

### TODO 1.1: take_damage(pokemon, amount)

Reduce Pokemon's current HP by the damage amount.

**Requirements:**
- Subtract amount from current_hp
- HP must never go below 0
- Modify the dictionary directly (no return value)

**Hint**: Use `max()` function to set a minimum value.

### TODO 1.2: is_fainted(pokemon)

Check if Pokemon has fainted.

**Requirements:**
- Return True if current_hp is 0 or less
- Return False otherwise

**Hint**: Simple comparison using `<=` operator.

### TODO 1.3: get_stat(pokemon, stat_name)

Get a stat value by name from the stats dictionary.

**Requirements:**
- Return the stat value for the given stat_name
- Return 0 if stat doesn't exist (defensive programming)

**Python feature to learn**: Dictionary `.get(key, default)` method
- First parameter: the key to look up
- Second parameter: value to return if key doesn't exist

**Why?** Prevents errors when accessing potentially missing keys.

### TODO 1.4: get_hp_percentage(pokemon)

Calculate current HP as a percentage (0.0 to 1.0).

**Requirements:**
- Divide current_hp by max_hp
- Handle division by zero (return 0.0 if max_hp is 0)
- Return a float

**Hint**: Check if denominator is greater than 0 before dividing. Use a conditional expression.

---

## TODO 2: Team Management

**File**: `team.py`

### TODO 2.1: create_team()

Create empty team dictionary.

**Requirements:**
- Return dict with "pokemon_list" as empty list
- Return dict with "current_pokemon_index" set to 0

### TODO 2.2: add_pokemon(team, pokemon)

Add Pokemon to team (max 6).

**Requirements:**
- Check if team has fewer than 6 Pokemon
- If yes: append pokemon to the list and return True
- If no: don't add it and return False

**List operations needed:**
- `len(list)` - get length
- `list.append(item)` - add to end

### TODO 2.3: get_current_pokemon(team)

Get the active Pokemon.

**Requirements:**
- Get the index from current_pokemon_index
- Get the pokemon_list
- Validate index is within bounds (0 to list length - 1)
- Return pokemon at that index if valid, None if invalid

**Index validation pattern**: Check if index is between 0 (inclusive) and list length (exclusive).

### TODO 2.4: switch_pokemon(team, index)

Switch to different Pokemon by index.

**Requirements:**
- Validate index is within bounds
- If valid: update current_pokemon_index and return True
- If invalid: don't change anything and return False

---

## TODO 3: Team State Checks

### TODO 3.1: all_fainted(team)

**File**: `team.py`

Check if all Pokemon on a team have fainted.

**Requirements:**
- Loop through pokemon_list
- Check each Pokemon using is_fainted()
- Return False as soon as you find one that's not fainted
- Return True if all are fainted

**Pattern**: Use early return inside loop when condition is met.

### TODO 3.2: get_team_size(team)

**File**: `team.py`

Get number of Pokemon in team.

**Requirements:**
- Return length of pokemon_list

**Hint**: One-line function.

### TODO 3.3: has_type(pokemon, type_name)

**File**: `pokemon.py`

Check if Pokemon has a specific type.

**Requirements:**
- Check if type_name exists in pokemon's types list
- Return True or False

**Python operator to use**: `in` operator checks if value is in a list.

---

## TODO 4: Basic Move Mechanics

**File**: `move.py`

### TODO 4.1: check_hit(move)

Determine if move hits based on accuracy.

**How it works:**
- Moves have accuracy rating (0-100)
- Generate random number 1-100
- Move hits if random number ≤ accuracy

**Requirements:**
- Generate random integer from 1 to 100
- Compare to move's accuracy
- Return True if hits, False if misses

**Random module**: Already imported, use `random.randint(start, end)` for random integers (inclusive).

---

## Testing Your Implementation

### Running the Game
```bash
python main.py
```

### What to Test

1. **Pokemon State**: Damage, fainting, HP percentage
2. **Team Management**: Creating teams, adding Pokemon (6 limit), switching
3. **Team State**: Battle ending when all Pokemon faint
4. **Move Accuracy**: Moves hitting/missing based on accuracy

### Current Gameplay

- Battles work with placeholder damage (10 HP per hit)
- Player always attacks first (simplified)
- Can switch Pokemon
- Battle ends when all Pokemon faint
- Moves can miss

**Note**: Real damage calculation comes in Week 24!

---

## Common Pitfalls

### 1. Not Modifying the Dictionary
Don't create new variables - modify the dictionary directly.

### 2. Division by Zero
Always check denominator before dividing.

### 3. Index Out of Bounds
Validate indices before accessing list elements.

### 4. Not Using .get() for Dictionaries
Use `.get(key, default)` instead of `dict[key]` when key might not exist.

### 5. Off-by-One Errors
List of length 6 has valid indices 0-5, not 1-6.

### 6. Forgetting Return Values
Check function docstring - if it says "Returns:", you need a return statement.

---

## Debugging Tips

### Print Statements
Add prints to see what's happening inside functions.

### Check Dictionary Contents
Print entire dictionaries or specific values to inspect state.

### Test Individual Functions
Create test data and call functions in isolation to verify behavior.

---

## Python Features You'll Use

### Dictionary Operations
- Access: `dict["key"]`
- Modify: `dict["key"] = value`
- Safe access: `dict.get("key", default)`

### List Operations
- Length: `len(list)`
- Append: `list.append(item)`
- Access: `list[index]`
- Check bounds: `0 <= index < len(list)`

### Comparison Operators
- `<=`, `>=`, `==`, `<`, `>`

### Boolean Logic
- `and`, `or`, `not`

### Random Module
- `random.randint(min, max)` - inclusive on both ends

### Built-in Functions
- `max(value1, value2)` - returns larger value
- `len(collection)` - returns length

---

## Completion Checklist

Before Week 24:

- [ ] `take_damage()` reduces HP correctly and prevents negatives
- [ ] `is_fainted()` identifies fainted Pokemon
- [ ] `get_stat()` retrieves stats with safe defaults
- [ ] `get_hp_percentage()` calculates percentage and handles edge cases
- [ ] `create_team()` returns proper structure
- [ ] `add_pokemon()` enforces 6-Pokemon limit
- [ ] `get_current_pokemon()` handles invalid indices
- [ ] `switch_pokemon()` validates before switching
- [ ] `all_fainted()` checks entire team
- [ ] `get_team_size()` returns correct count
- [ ] `has_type()` checks types correctly
- [ ] `check_hit()` uses randomness appropriately
- [ ] You can complete a full battle

---

## Next Week Preview

Week 24: **Battle System & Combat**
- Pokemon damage calculation formula
- STAB (Same Type Attack Bonus)
- Type effectiveness integration
- Speed-based turn order
- Full battle orchestration

Get ready to implement real Pokemon battles!

---

Good luck building your Pokemon game foundation! 🎮
